package com.example.myapplication44;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        onClick();


    }


    public void onClick() {
        final Button a = (Button) findViewById(R.id.button);
        final ImageView c = (ImageView) findViewById(R.id.image);
        final TextView b = (TextView) findViewById(R.id.textView);
        a.setOnClickListener((view) -> {
            System.out.println("Eliyahu");
            b.setText("Eliyahu and youni");
            a.setText("is clicked !!");
            
        });
    }

}